from flask import Flask, render_template, request
import pickle
import numpy as np
import os

app = Flask(__name__)

# Load model
model_path = os.path.join(os.path.dirname(__file__), "model.pkl")
with open(model_path, "rb") as f:
    model = pickle.load(f)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Automatically collect all 15 features from the form
        features = []
        for i in range(1, 16):
            value = request.form.get(f"feature{i}")
            # Convert to float if not empty, else default to 0
            features.append(float(value) if value else 0.0)

        features_array = np.array([features])
        prediction = model.predict(features_array)[0]

        return render_template(
            "index.html",
            prediction_text=f"Predicted House Price: ${prediction:,.2f}"
        )

    except Exception as e:
        return render_template("index.html", prediction_text=f"Error: {str(e)}")

if __name__ == "__main__":
    app.run(debug=True)
